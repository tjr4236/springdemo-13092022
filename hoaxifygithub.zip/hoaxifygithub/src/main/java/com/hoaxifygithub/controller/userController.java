package com.hoaxifygithub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hoaxifygithub.dao.UserDAO;
import com.hoaxifygithub.model.User;



@RestController
public class userController {

	@Autowired
	private UserDAO uDAO;

	@PostMapping("/api/1.0/users")
	public String createUser(@RequestBody User user) {
		return uDAO.Create_User_Save_DB(user) + "No. of rows saved to the database";
	}

}
