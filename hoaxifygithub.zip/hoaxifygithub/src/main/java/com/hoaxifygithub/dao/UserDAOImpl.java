package com.hoaxifygithub.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.hoaxifygithub.model.User;

@Repository
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public int Create_User_Save_DB(User user) {
		
		return jdbcTemplate.update("INSERT INTO hoaxify_users1(ID,USERNAME,PASSWORD,DISPLAYNAME,ENABLED) values(?,?,?,?,?)",
				new Object[] {user.getUsername(),user.getDisplayName(),user.getPassword(),user.getId(),user.getEnabled()});
			}

	
		
		
	}


