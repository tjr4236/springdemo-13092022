package com.hoaxifygithub.dao;

import com.hoaxifygithub.model.User;

public interface UserDAO {
	
	
	int Create_User_Save_DB(User user); // takes the employee object and  returns the int
	//int update(User user, int id);
	//int delete(int id);
	//List<User> getAll();
	//User getById(int id);


}
