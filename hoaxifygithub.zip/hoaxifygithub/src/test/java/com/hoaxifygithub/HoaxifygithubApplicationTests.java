package com.hoaxifygithub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoaxifygithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
